from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from auth import get_current_user
from models import User, Feedback
from schemas import FeedbackCreate, FeedbackOut
from datetime import datetime

manager_router = APIRouter()

@manager_router.get("/team")
def get_team(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "manager":
        raise HTTPException(status_code=403, detail="Unauthorized")
    return db.query(User).filter(User.role == "employee").all()

@manager_router.post("/feedback/{employee_id}")
def give_feedback(employee_id: int, data: FeedbackCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "manager":
        raise HTTPException(status_code=403, detail="Only managers can give feedback")
    feedback = Feedback(
        strengths=data.strengths,
        improvements=data.improvements,
        sentiment=data.sentiment,
        comment=data.comment,
        manager_id=current_user.id,
        employee_id=employee_id,
        created_at=datetime.utcnow()
    )
    db.add(feedback)
    db.commit()
    return {"message": "Feedback submitted"}
