from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from auth import get_current_user
from models import Feedback, User
from schemas import FeedbackCreate, FeedbackOut
from datetime import datetime

employee_router = APIRouter()

@employee_router.get("/feedback/{employee_id}", response_model=list[FeedbackOut])
def get_feedback_for_employee(employee_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "employee" or current_user.id != employee_id:
        raise HTTPException(status_code=403, detail="Unauthorized")
    return db.query(Feedback).filter(Feedback.employee_id == employee_id).all()

@employee_router.post("/feedback/{manager_id}")
def give_feedback_to_manager(manager_id: int, data: FeedbackCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "employee":
        raise HTTPException(status_code=403, detail="Only employees can give feedback")
    feedback = Feedback(
        strengths=data.strengths,
        improvements=data.improvements,
        sentiment=data.sentiment,
        comment=data.comment,
        employee_id=current_user.id,
        manager_id=manager_id,
        created_at=datetime.utcnow()
    )
    db.add(feedback)
    db.commit()
    return {"message": "Feedback submitted"}
